import React from 'react'
import { createRoot } from 'react-dom/client'
import { ShieldCheck, LockKeyhole, BrainCircuit, Network, FileCheck2, ArrowRight, Cloud, KeyRound, Activity, CheckCircle2 } from 'lucide-react'
import './styles.css'

const pillars = [
  { icon: ShieldCheck, title: 'AI Model Access Control', body: 'Inspect prompts, enforce model access rules, redact sensitive inputs, and validate AI responses before exposure happens.' },
  { icon: LockKeyhole, title: 'Autonomous Data Governance', body: 'Govern identity, intent, policy, classification, tokenization, approvals, and audit evidence across regulated AI workflows.' },
  { icon: FileCheck2, title: 'Audit-Ready Evidence', body: 'Capture who accessed what, why, under which policy, and what protection decision was applied.' },
]

const architecture = ['AI Access Gateway', 'Identity + Intent Context', 'Policy Decision Engine', 'Sensitive Data Classifier', 'Tokenization + Redaction', 'Amazon Bedrock Integration', 'Response Inspection', 'Audit Evidence Dashboard']
const outcomes = ['Use AI with sensitive data without exposing raw sensitive data.', 'Apply policy decisions before prompts reach the model.', 'Tokenize, redact, mask, or deny restricted data in real time.', 'Create a path from POC to production-ready AI governance.']

function LogoMark() {
  return (
    <div className="logo-wrap" aria-label="DigiTrans logo">
      <div className="logo-mark"><div className="logo-inner" /><div className="logo-d" /><div className="logo-t" /><div className="logo-line" /></div>
      <div><div className="logo-name">DigiTrans</div><div className="logo-tag">Trusted AI Data</div></div>
    </div>
  )
}

function App() {
  return (
    <main>
      <section className="hero">
        <div className="grid-bg" />
        <div className="container nav-container">
          <nav>
            <LogoMark />
            <div className="nav-links"><a href="#platform">Platform</a><a href="#pocs">POCs</a><a href="#architecture">Architecture</a><a href="#contact">Contact</a></div>
            <a className="button primary" href="#contact">Request POC</a>
          </nav>
          <div className="hero-layout">
            <div className="hero-copy">
              <div className="eyebrow"><Activity size={16} /> AWS-aligned regulated AI governance</div>
              <h1>Use AI with sensitive data, <span>without exposing sensitive data.</span></h1>
              <p>DigiTrans is building the privacy control plane for regulated AI. Govern prompts, model access, sensitive data, tokenization, redaction, approvals, and audit evidence before data reaches AI models.</p>
              <div className="hero-actions"><a className="button primary large" href="#pocs">Explore the POC Model <ArrowRight size={16} /></a><a className="button secondary large" href="#architecture">View Architecture</a></div>
            </div>
            <div className="architecture-card"><div className="card-inner"><div className="card-top"><span>Governed AI Request</span><span className="status">Protected</span></div><div className="steps">{architecture.map((item, index) => (<div className="step" key={item}><div className="step-number">{index + 1}</div><div>{item}</div></div>))}</div></div></div>
          </div>
        </div>
      </section>
      <section id="platform" className="container section">
        <div className="section-intro"><h2>Privacy infrastructure for regulated AI.</h2><p>DigiTrans creates a governed path between sensitive enterprise data and AI models, helping security, privacy, data, and AI teams move faster with stronger controls.</p></div>
        <div className="pillars">{pillars.map((pillar) => { const Icon = pillar.icon; return <article className="pillar" key={pillar.title}><Icon className="pillar-icon" size={38} /><h3>{pillar.title}</h3><p>{pillar.body}</p></article> })}</div>
      </section>
      <section id="pocs" className="container section">
        <div className="poc-grid">
          <article className="poc-card cyan"><BrainCircuit size={42} /><div className="label">POC 1</div><h3>AI Model Access Control / Guardrail Layer</h3><p>A fast wedge POC that protects prompts, model inputs, model access, model routing, and AI outputs.</p><ul><li>Prompt inspection and sensitive-data detection</li><li>Input redaction and tokenization before Bedrock</li><li>Response inspection and AI usage audit logs</li></ul></article>
          <article className="poc-card blue"><Network size={42} /><div className="label">POC 2</div><h3>Autonomous AI Data Access Governance Control Plane</h3><p>A strategic platform POC that governs identity, intent, policy, data classification, tokenization, approvals, AI access, and evidence.</p><ul><li>Policy decisions: allow, deny, redact, tokenize, mask, aggregate, escalate</li><li>Sensitive-data governance across users, agents, apps, and models</li><li>Audit evidence dashboard for regulated AI workflows</li></ul></article>
        </div>
      </section>
      <section id="architecture" className="container section">
        <div className="service-card"><div className="service-title"><Cloud size={34} /><h2>AWS-aligned reference architecture</h2></div><div className="aws-grid">{['Amazon Bedrock', 'API Gateway', 'AWS Lambda', 'IAM / Cognito', 'S3', 'DynamoDB / Aurora', 'KMS + Secrets Manager', 'CloudTrail + CloudWatch', 'OpenSearch', 'QuickSight', 'Step Functions', 'EventBridge'].map((item) => (<div className="aws-item" key={item}>{item}</div>))}</div></div>
      </section>
      <section className="container section"><div className="outcomes-layout"><div><KeyRound className="accent-icon" size={42} /><h2>Designed for customer-ready POCs.</h2><p>DarcyIQ supports discovery and opportunity packaging. Innovative Solutions supports AWS delivery. DigiTrans owns the product/IP and platform strategy.</p></div><div className="outcomes">{outcomes.map((outcome) => (<div className="outcome" key={outcome}><CheckCircle2 size={21} /><span>{outcome}</span></div>))}</div></div></section>
      <section id="contact" className="container contact"><h2>Ready to govern regulated AI?</h2><p>Start with a focused 90-day POC and expand into the DigiTrans Regulated AI Governance Control Plane.</p><a className="button primary large" href="mailto:hello@digitrans.ai?subject=DigiTrans%20POC%20Request">Contact DigiTrans</a></section>
      <footer>© 2026 DigiTrans LLC. All rights reserved.</footer>
    </main>
  )
}

createRoot(document.getElementById('root')).render(<App />)
