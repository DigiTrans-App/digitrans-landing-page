# DigiTrans AWS Amplify Landing Page

This package contains a deploy-ready React/Vite landing page for DigiTrans.

## Local preview

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```

Build output is generated in the `dist/` directory.

## AWS Amplify deployment

1. Create a new GitHub repository, for example `digitrans-landing-page`.
2. Upload/push the contents of this folder to the repo.
3. Open AWS Amplify Hosting.
4. Choose **Deploy an app** > connect GitHub.
5. Select the repository and `main` branch.
6. Use the included `amplify.yml` build settings.
7. Deploy.

## Custom domain: digitrans.ai

After deployment:

1. In Amplify, open the app.
2. Go to **Hosting > Custom domains**.
3. Choose **Add domain**.
4. Enter `digitrans.ai`.
5. Configure:
   - Root domain: `digitrans.ai`
   - Subdomain: `www.digitrans.ai`
   - Recommended redirect: `digitrans.ai` -> `www.digitrans.ai`
6. If the domain is in Route 53, Amplify can create the records for you.
7. If the domain is with a third-party registrar, copy the DNS records Amplify provides into that registrar's DNS manager.
8. Wait for SSL certificate validation and DNS propagation.

Recommended public URL: `https://www.digitrans.ai`
